from __future__ import annotations

import threading
import time
from typing import Dict, Optional
from enum import Enum

from .models import Order, OrderType, Side, Fill, Quote, EngineState
from .portfolio import Portfolio

class StopCondition(Enum):
    NONE = "NONE"
    STOP_LOSS = "STOP_LOSS"  # Triggers when price <= stop (long) or >= stop (short)
    TAKE_PROFIT = "TAKE_PROFIT"  # Triggers when price >= stop (long) or <= stop (short)

class TradingEngine:
    """Simple single-book engine supporting MARKET, LIMIT orders and conditional stops against last trade price."""

    def __init__(self, portfolio: Portfolio):
        self._portfolio = portfolio
        self._state = EngineState()
        self._quotes: Dict[str, Quote] = {}
        self._lock = threading.RLock()

    def on_quote(self, quote: Quote) -> None:
        with self._lock:
            old_quote = self._quotes.get(quote.symbol)
            self._quotes[quote.symbol] = quote   
            self._try_match_limits_for_symbol(quote.symbol)
            self._try_match_stops_for_symbol(quote.symbol, old_quote)

    def place_order(self, order: Order) -> Optional[Fill]:
        order.validate()
        with self._lock:
            # Get current quote for margin check
            quote = self._quotes.get(order.symbol)
            if not quote:
                raise ValueError(f"No market data for symbol {order.symbol}")
            
            # Check if there's sufficient margin
            pstate = self._portfolio.get_state()
            if not pstate.has_sufficient_margin(self._quotes, order.symbol, order.quantity, quote.price):
                raise ValueError(
                    f"Insufficient margin. Required: ${order.quantity * quote.price * 0.5:,.2f}, "
                    f"Available: ${pstate.available_margin(self._quotes):,.2f}"
                )
            
            if order.order_type == OrderType.MARKET:
                fill = Fill(
                    order_id=order.id,
                    symbol=order.symbol,
                    side=order.side,
                    quantity=order.quantity,
                    price=quote.price,
                    timestamp=time.time(),
                )
                self._apply_fill(fill)
                return fill
            else:
                self._state.open_orders[order.id] = order
                # Try immediate match if already marketable
                if order.order_type == OrderType.LIMIT:
                    self._try_match_limit(order)
                return None

    def _try_match_stops_for_symbol(self, symbol: str, old_quote: Optional[Quote]) -> None:
        if not old_quote:
            return
        
        current_quote = self._quotes[symbol]
        for order in list(self._state.open_orders.values()):
            if order.symbol != symbol or not order.stop_condition:
                continue
                
            # For stop loss:
            # Long position: trigger when price falls below stop
            # Short position: trigger when price rises above stop
            # For take profit:
            # Long position: trigger when price rises above stop
            # Short position: trigger when price falls below stop
            
            is_long = order.side == Side.BUY
            if order.stop_condition == StopCondition.STOP_LOSS:
                triggered = (is_long and current_quote.price <= order.stop_price) or \
                           (not is_long and current_quote.price >= order.stop_price)
            else:  # TAKE_PROFIT
                triggered = (is_long and current_quote.price >= order.stop_price) or \
                           (not is_long and current_quote.price <= order.stop_price)
                
            if triggered:
                self._state.open_orders.pop(order.id, None)
                fill = Fill(
                    order_id=order.id,
                    symbol=order.symbol,
                    side=order.side,
                    quantity=order.quantity,
                    price=current_quote.price,
                    timestamp=time.time(),
                )
                self._apply_fill(fill)

    def cancel_order(self, order_id: str) -> bool:
        with self._lock:
            return self._state.open_orders.pop(order_id, None) is not None

    def get_state(self) -> EngineState:
        with self._lock:
            return EngineState(open_orders=dict(self._state.open_orders), fills=list(self._state.fills))

    def get_quotes(self) -> Dict[str, Quote]:
        with self._lock:
            return dict(self._quotes)

    def _try_match_limits_for_symbol(self, symbol: str) -> None:
        for order in list(self._state.open_orders.values()):
            if order.symbol == symbol and order.order_type == OrderType.LIMIT:
                self._try_match_limit(order)

    def _try_match_limit(self, order: Order) -> None:
        quote = self._quotes.get(order.symbol)
        if not quote:
            return
        assert order.limit_price is not None
        is_marketable = (
            (order.side == Side.BUY and quote.price <= order.limit_price)
            or (order.side == Side.SELL and quote.price >= order.limit_price)
        )
        if is_marketable:
            self._state.open_orders.pop(order.id, None)
            fill = Fill(
                order_id=order.id,
                symbol=order.symbol,
                side=order.side,
                quantity=order.quantity,
                price=quote.price,
                timestamp=time.time(),
            )
            self._apply_fill(fill)

    def _apply_fill(self, fill: Fill) -> None:
        self._state.fills.append(fill)
        self._portfolio.apply_fill(fill)

    # Persistence helpers
    def load_state(self, state: EngineState) -> None:
        with self._lock:
            self._state = EngineState(open_orders=dict(state.open_orders), fills=list(state.fills))

    def clear_history(self) -> None:
        with self._lock:
            self._state.fills.clear()


