from __future__ import annotations

import threading
from typing import Dict

from .models import Fill, PortfolioState, Position, Quote, Side


class Portfolio:
    def __init__(self, starting_cash: float = 100000.0):
        self._state = PortfolioState(cash=starting_cash)
        self._lock = threading.RLock()

    def apply_fill(self, fill: Fill) -> None:
        with self._lock:
            pos = self._state.positions.get(fill.symbol)
            if not pos:
                pos = Position(symbol=fill.symbol)
                self._state.positions[fill.symbol] = pos
            # Cash impact: BUY decreases cash, SELL increases cash
            if fill.side == Side.BUY:
                cost = fill.price * fill.quantity
                self._state.cash -= cost
            else:
                proceeds = fill.price * fill.quantity
                self._state.cash += proceeds
            realized = pos.apply_fill(fill)
            self._state.realized_pnl += realized

    def get_state(self) -> PortfolioState:
        with self._lock:
            # Shallow copies are fine here
            return PortfolioState(
                cash=self._state.cash,
                positions={k: Position(symbol=v.symbol, quantity=v.quantity, average_price=v.average_price) for k, v in self._state.positions.items()},
                realized_pnl=self._state.realized_pnl,
            )

    def equity(self, quotes: Dict[str, Quote]) -> float:
        with self._lock:
            return self._state.total_equity(quotes)

    def load_state(self, state: PortfolioState) -> None:
        with self._lock:
            # Replace entire state atomically
            self._state = PortfolioState(
                cash=state.cash,
                positions={k: Position(symbol=v.symbol, quantity=v.quantity, average_price=v.average_price) for k, v in state.positions.items()},
                realized_pnl=state.realized_pnl,
            )


