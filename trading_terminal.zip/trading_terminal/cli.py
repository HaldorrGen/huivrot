from __future__ import annotations

import os
import time
from typing import List

from .data_feed import SimulatedDataFeed
from .engine import TradingEngine
from .models import Order, OrderType, Side, StopCondition
from .portfolio import Portfolio
from .persistence import (
    portfolio_state_from_dict,
    portfolio_state_to_dict,
    engine_state_from_dict,
    engine_state_to_dict,
    save_json,
    load_json,
)


STATE_DIR = os.path.join(os.getcwd(), "trading_state")
PORTFOLIO_PATH = os.path.join(STATE_DIR, "portfolio.json")
ENGINE_PATH = os.path.join(STATE_DIR, "engine.json")


def ensure_state_dir() -> None:
    if not os.path.isdir(STATE_DIR):
        os.makedirs(STATE_DIR, exist_ok=True)


def load_or_create(portfolio: Portfolio, engine: TradingEngine) -> None:
    ensure_state_dir()
    if os.path.isfile(PORTFOLIO_PATH):
        try:
            pdata = load_json(PORTFOLIO_PATH)
            pstate = portfolio_state_from_dict(pdata)
            portfolio._state = pstate  # type: ignore[attr-defined]
        except Exception:
            pass
    if os.path.isfile(ENGINE_PATH):
        try:
            edata = load_json(ENGINE_PATH)
            estate = engine_state_from_dict(edata)
            engine._state = estate  # type: ignore[attr-defined]
        except Exception:
            pass


def save_state(portfolio: Portfolio, engine: TradingEngine) -> None:
    ensure_state_dir()
    try:
        save_json(PORTFOLIO_PATH, portfolio_state_to_dict(portfolio.get_state()))
        save_json(ENGINE_PATH, engine_state_to_dict(engine.get_state()))
    except Exception:
        pass


def clear_screen() -> None:
    os.system("cls" if os.name == "nt" else "clear")


def format_money(v: float) -> str:
    return f"$ {v:,.2f}"


def main_loop(symbols: List[str]) -> None:
    feed = SimulatedDataFeed(symbols=symbols, initial_price=100.0, tick_seconds=1.0)
    portfolio = Portfolio(starting_cash=100000.0)
    engine = TradingEngine(portfolio)
    load_or_create(portfolio, engine)
    feed.subscribe(engine.on_quote)
    feed.start()

    try:
        while True:
            clear_screen()
            quotes = engine.get_quotes() or feed.get_last_quotes()
            pstate = portfolio.get_state()
            eq = pstate.total_equity(quotes)
            avail_margin = pstate.available_margin(quotes)

            print("=== Paper Trading Terminal ===")
            print("Symbols:", ", ".join(symbols))
            print("Cash:", format_money(pstate.cash), " Realized PnL:", format_money(pstate.realized_pnl), " Equity:", format_money(eq))
            print("Required Margin:", format_money(pstate.get_required_margin(quotes)), " Available Margin:", format_money(avail_margin))
            print()
            print("Quotes:")
            for s in symbols:
                q = quotes.get(s)
                if q:
                    print(f"  {s}: {q.price:.2f}")
            print()
            if pstate.positions:
                print("Positions:")
                for sym, pos in pstate.positions.items():
                    q = quotes.get(sym)
                    mark = q.price if q else pos.average_price
                    unreal = (mark - pos.average_price) * pos.quantity
                    print(f"  {sym}: qty={pos.quantity} avg={pos.average_price:.2f} unreal={unreal:.2f}")
                print()

            est = engine.get_state()
            if est.open_orders:
                print("Open Orders:")
                for oid, od in est.open_orders.items():
                    lp = f" @{od.limit_price:.2f}" if od.limit_price is not None else ""
                    stop = f" SL@{od.stop_price:.2f}" if od.stop_price is not None else ""
                    print(f"  {oid[:8]} {od.side} {od.quantity} {od.symbol} {od.order_type}{lp}{stop}")
                print()

            print("Menu: [1] Buy [2] Sell [3] Cancel Order [4] Save [5] Quit")
            choice = input("> ").strip()
            if choice == "1" or choice.lower() == "buy":
                _place_order_flow(engine, symbols, Side.BUY)
            elif choice == "2" or choice.lower() == "sell":
                _place_order_flow(engine, symbols, Side.SELL)
            elif choice == "3":
                oid = input("Order ID (prefix ok): ").strip()
                found = None
                for ko in list(est.open_orders.keys()):
                    if ko.startswith(oid):
                        found = ko
                        break
                if found:
                    ok = engine.cancel_order(found)
                    print("Cancelled" if ok else "Not found")
                else:
                    print("Not found")
                time.sleep(1.0)
            elif choice == "4":
                save_state(portfolio, engine)
                print("Saved.")
                time.sleep(1.0)
            elif choice == "5" or choice.lower() in ("q", "quit", "exit"):
                save_state(portfolio, engine)
                break
            else:
                # no-op; loop refresh
                pass
    finally:
        feed.stop()


def _place_order_flow(engine: TradingEngine, symbols: List[str], side: Side) -> None:
    sym = input("Symbol: ").strip().upper()
    if sym not in symbols:
        print("Unknown symbol")
        time.sleep(1.0)
        return
    qty_s = input("Quantity: ").strip()
    try:
        qty = int(qty_s)
        if qty <= 0:
            raise ValueError
    except Exception:
        print("Invalid quantity")
        time.sleep(1.0)
        return
    typ = input("Type [M]arket/[L]imit: ").strip().lower()
    if typ in ("m", "market", ""):
        order = Order(symbol=sym, side=side, quantity=qty, order_type=OrderType.MARKET)
        try:
            fill = engine.place_order(order)
            if fill:
                print(f"Filled {fill.side} {fill.quantity} {fill.symbol} @{fill.price:.2f}")
            time.sleep(1.0)
            return
        except ValueError as e:
            print(f"Error: {e}")
            time.sleep(2.0)
            return
    elif typ in ("l", "limit"):
        lp_s = input("Limit price: ").strip()
        try:
            lp = float(lp_s)
            stop_loss = input("Stop loss price (optional): ").strip()
            stop_price = None
            if stop_loss:
                stop_price = float(stop_loss)
            
            order = Order(
                symbol=sym, 
                side=side, 
                quantity=qty, 
                order_type=OrderType.LIMIT, 
                limit_price=lp,
                stop_price=stop_price,
                stop_condition=StopCondition.STOP_LOSS if stop_price else StopCondition.NONE
            )
            engine.place_order(order)
            print("Order placed.")
            time.sleep(1.0)
            return
        except ValueError as e:
            print(f"Error: {e}")
            time.sleep(2.0)
            return
        except Exception:
            print("Invalid input")
            time.sleep(1.0)
            return
    else:
        print("Unknown type")
        time.sleep(1.0)



