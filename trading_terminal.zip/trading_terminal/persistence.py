from __future__ import annotations

import json
from typing import Dict, Any

from .models import PortfolioState, Position, EngineState, Order, OrderType, Side, Fill


def portfolio_state_to_dict(state: PortfolioState) -> Dict[str, Any]:
    return {
        "cash": state.cash,
        "realized_pnl": state.realized_pnl,
        "positions": {
            sym: {"symbol": p.symbol, "quantity": p.quantity, "average_price": p.average_price}
            for sym, p in state.positions.items()
        },
    }


def portfolio_state_from_dict(data: Dict[str, Any]) -> PortfolioState:
    positions = {
        sym: Position(symbol=v["symbol"], quantity=int(v["quantity"]), average_price=float(v["average_price"]))
        for sym, v in data.get("positions", {}).items()
    }
    return PortfolioState(
        cash=float(data.get("cash", 0.0)),
        positions=positions,
        realized_pnl=float(data.get("realized_pnl", 0.0)),
    )


def engine_state_to_dict(state: EngineState) -> Dict[str, Any]:
    return {
        "open_orders": {oid: _order_to_dict(o) for oid, o in state.open_orders.items()},
        "fills": [
            {
                "order_id": f.order_id,
                "symbol": f.symbol,
                "side": f.side.value,
                "quantity": f.quantity,
                "price": f.price,
                "timestamp": f.timestamp,
            }
            for f in state.fills
        ],
    }


def _order_to_dict(o: Order) -> Dict[str, Any]:
    return {
        "id": o.id,
        "symbol": o.symbol,
        "side": o.side.value,
        "quantity": o.quantity,
        "order_type": o.order_type.value,
        "limit_price": o.limit_price,
        "timestamp": o.timestamp,
    }


def _order_from_dict(d: Dict[str, Any]) -> Order:
    return Order(
        id=d.get("id"),
        symbol=d["symbol"],
        side=Side(d["side"]),
        quantity=int(d["quantity"]),
        order_type=OrderType(d["order_type"]),
        limit_price=float(d["limit_price"]) if d.get("limit_price") is not None else None,
        timestamp=float(d.get("timestamp")) if d.get("timestamp") is not None else None,
    )


def _fill_from_dict(d: Dict[str, Any]) -> Fill:
    return Fill(
        order_id=d["order_id"],
        symbol=d["symbol"],
        side=Side(d["side"]),
        quantity=int(d["quantity"]),
        price=float(d["price"]),
        timestamp=float(d["timestamp"]),
    )


def engine_state_from_dict(data: Dict[str, Any]) -> EngineState:
    open_orders = {oid: _order_from_dict(od) for oid, od in data.get("open_orders", {}).items()}
    fills = [_fill_from_dict(fd) for fd in data.get("fills", [])]
    return EngineState(open_orders=open_orders, fills=fills)


def save_json(path: str, data: Dict[str, Any]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


