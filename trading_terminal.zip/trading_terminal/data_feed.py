from __future__ import annotations

import random
import threading
import time
from typing import Dict, Callable, List, Tuple, Optional
from enum import Enum
from datetime import datetime, time as dt_time
import math
import numpy as np
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("data_feed.log"),
        logging.StreamHandler()
    ]
)

from .models import Quote

class MarketRegime(Enum):
    BULL = "BULL"  # Trending up, lower volatility
    BEAR = "BEAR"  # Trending down, higher volatility
    SIDEWAYS = "SIDEWAYS"  # Range-bound, medium volatility
    VOLATILE = "VOLATILE"  # No clear trend, very high volatility

class SimulatedDataFeed:
    """Enhanced simulated data feed with realistic market behavior.
    
    Features:
    - Market regimes (bull/bear/sideways/volatile)
    - Intraday patterns (U-shape volatility)
    - Volume simulation
    - Correlated asset movements
    - Bid-ask spread simulation
    - Trading hours simulation
    """

    def __init__(
        self,
        symbols: List[str],
        initial_price: float = 100.0,
        tick_seconds: float = 1.0,
        initial_prices: Optional[Dict[str, float]] = None,
        mu: Optional[Dict[str, float]] = None,
        sigma: Optional[Dict[str, float]] = None,
    ):
        self._symbols = list(symbols)
        self._prices: Dict[str, float] = {
            s: float((initial_prices or {}).get(s, initial_price)) for s in self._symbols
        }
        self._volumes: Dict[str, float] = {s: 0.0 for s in self._symbols}
        self._spreads: Dict[str, float] = {s: 0.01 for s in self._symbols}  # 1% default spread
        self._tick_seconds = tick_seconds
        self._subscribers: List[Callable[[Quote], None]] = []
        self._lock = threading.RLock()
        self._running = False
        self._thread: threading.Thread | None = None
        self._impulses: Dict[str, List[Tuple[float, float]]] = {s: [] for s in self._symbols}
        
        # Market regime parameters
        self._current_regime = MarketRegime.SIDEWAYS
        self._regime_change_prob = 0.001  # Probability of regime change per tick
        self._regime_params = {
            MarketRegime.BULL: {"mu_mult": 2.0, "sigma_mult": 0.8},
            MarketRegime.BEAR: {"mu_mult": -2.0, "sigma_mult": 1.5},
            MarketRegime.SIDEWAYS: {"mu_mult": 0.0, "sigma_mult": 1.0},
            MarketRegime.VOLATILE: {"mu_mult": 0.0, "sigma_mult": 2.5},
        }
        
        # Base parameters (per-second units)
        self._mu: Dict[str, float] = {s: (mu or {}).get(s, 0.0) for s in self._symbols}
        self._sigma: Dict[str, float] = {s: (sigma or {}).get(s, 0.002) for s in self._symbols}
        
        # Correlation matrix (simple example - tech stocks more correlated)
        self._correlations = np.eye(len(symbols))
        tech_symbols = ["AAPL", "MSFT", "GOOG", "NVDA", "AMD"]
        tech_indices = [i for i, s in enumerate(symbols) if s in tech_symbols]
        for i in tech_indices:
            for j in tech_indices:
                if i != j:
                    self._correlations[i, j] = 0.7
        
        # ETF definitions: symbol -> (weights, scale)
        self._etfs: Dict[str, Tuple[Dict[str, float], float]] = {}

    def _get_intraday_factors(self) -> Tuple[float, float]:
        """Get intraday volatility and volume multipliers based on time of day.
        
        Returns:
            Tuple[float, float]: (volatility multiplier, volume multiplier)
        
        Implements U-shaped patterns typical in market microstructure:
        - Higher volatility and volume at open and close
        - Lower activity during lunch hours
        """
        now = datetime.now().time()
        
        # Market hours: 9:30 AM - 4:00 PM ET
        market_open = dt_time(9, 30)
        market_close = dt_time(16, 0)
        lunch_start = dt_time(12, 0)
        lunch_end = dt_time(13, 0)
        
        # Outside market hours
        if now < market_open or now > market_close:
            return 0.2, 0.1  # Low volatility and volume
            
        # Convert to minutes from open
        minutes_from_open = (now.hour - market_open.hour) * 60 + (now.minute - market_open.minute)
        total_market_minutes = (market_close.hour - market_open.hour) * 60
        
        # U-shape base pattern
        normalized_time = minutes_from_open / total_market_minutes
        u_shape = 1.0 + 0.5 * (math.exp(-normalized_time * 10) + math.exp(-(1-normalized_time) * 10))
        
        # Lunch hour dampening
        if lunch_start <= now <= lunch_end:
            u_shape *= 0.7
            
        return u_shape, u_shape * 1.2  # Volume slightly more pronounced

    def _update_regime(self) -> None:
        """Potentially change market regime based on probability."""
        if random.random() < self._regime_change_prob:
            # Weights favor continuing current regime
            weights = [0.7 if r == self._current_regime else 0.1 for r in MarketRegime]
            self._current_regime = random.choices(list(MarketRegime), weights=weights)[0]

    def _simulate_correlated_returns(self, vol_factor: float) -> Dict[str, float]:
        """Generate correlated returns across all symbols."""
        regime = self._regime_params[self._current_regime]
        mu_mult, sigma_mult = regime["mu_mult"], regime["sigma_mult"]
        
        # Generate correlated normal variates
        n = len(self._symbols)
        z = np.random.multivariate_normal(np.zeros(n), self._correlations)
        
        returns = {}
        for i, sym in enumerate(self._symbols):
            mu_s = self._mu[sym] * mu_mult
            sigma_s = self._sigma[sym] * sigma_mult * vol_factor
            # Log-return increment with correlation
            returns[sym] = (mu_s - 0.5 * sigma_s * sigma_s) * self._tick_seconds + \
                         sigma_s * math.sqrt(self._tick_seconds) * z[i]
        return returns

    def _simulate_volumes(self, vol_mult: float) -> Dict[str, float]:
        """Simulate trading volumes for each symbol."""
        volumes = {}
        for sym in self._symbols:
            # Base volume proportional to price
            base = self._prices[sym] * 0.0001  # 0.01% of price
            # Add randomness
            noise = random.lognormvariate(0, 0.5)
            volumes[sym] = base * vol_mult * noise
        return volumes

    def _update_spreads(self) -> None:
        """Update bid-ask spreads based on volatility and volume."""
        for sym in self._symbols:
            # Spread widens with volatility and tightens with volume
            vol = self._sigma[sym] * self._regime_params[self._current_regime]["sigma_mult"]
            base_spread = 0.0001 + vol * 50  # 1bp minimum + vol-based component
            vol_factor = math.sqrt(self._volumes[sym] / self._prices[sym])
            self._spreads[sym] = base_spread / vol_factor

    def _run_loop(self) -> None:
        while self._running:
            time.sleep(self._tick_seconds)
            with self._lock:
                # Update market regime
                self._update_regime()
                
                # Get intraday factors
                vol_factor, vol_mult = self._get_intraday_factors()
                
                # Generate correlated returns
                returns = self._simulate_correlated_returns(vol_factor)
                
                # Update volumes
                self._volumes = self._simulate_volumes(vol_mult)
                
                # Update spreads
                self._update_spreads()
                
                # Apply returns and create quotes
                now = time.time()
                for sym in self._symbols:
                    # Sum any active impulses and decay them
                    impulse_r = 0.0
                    if self._impulses[sym]:
                        new_list = []
                        for strength, decay in self._impulses[sym]:
                            impulse_r += strength
                            strength *= decay
                            if abs(strength) > 1e-5:
                                new_list.append((strength, decay))
                        self._impulses[sym] = new_list
                    
                    # Update price with return + impulses
                    log_ret = returns[sym] + impulse_r
                    new_price = self._prices[sym] * math.exp(log_ret)
                    self._prices[sym] = max(0.01, new_price)
                    
                    # Create quote with mid price
                    mid = self._prices[sym]
                    spread = self._spreads[sym] * mid
                    quote = Quote(
                        symbol=sym,
                        price=mid,
                        bid=mid - spread/2,
                        ask=mid + spread/2,
                        volume=self._volumes[sym],
                        timestamp=now
                    )
                    
                    for cb in self._subscribers:
                        try:
                            cb(quote)
                        except Exception:
                            pass

                # Update ETF prices
                if self._etfs:
                    for etf_sym, (weights, scale) in self._etfs.items():
                        nav = sum(w * self._prices[usym] for usym, w in weights.items())
                        self._prices[etf_sym] = max(0.01, nav * scale)
                        spread = self._spreads.get(etf_sym, 0.0001) * self._prices[etf_sym]
                        quote = Quote(
                            symbol=etf_sym,
                            price=self._prices[etf_sym],
                            bid=self._prices[etf_sym] - spread/2,
                            ask=self._prices[etf_sym] + spread/2,
                            volume=sum(self._volumes.get(usym, 0) for usym in weights),
                            timestamp=now
                        )
                        for cb in self._subscribers:
                            try:
                                cb(quote)
                            except Exception:
                                pass

    def get_last_quotes(self) -> Dict[str, Quote]:
        logging.info("Fetching last quotes")
        with self._lock:
            now = time.time()
            quotes = {s: Quote(symbol=s, price=p, timestamp=now) for s, p in self._prices.items()}
        logging.info("Last quotes fetched successfully")
        return quotes

    def subscribe(self, callback: Callable[[Quote], None]) -> None:
        logging.info("Adding a new subscriber")
        with self._lock:
            self._subscribers.append(callback)
        logging.info("Subscriber added successfully")

    def start(self) -> None:
        logging.info("Starting data feed")
        if self._running:
            logging.warning("Data feed is already running")
            return
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, name="SimulatedDataFeed", daemon=True)
        self._thread.start()
        logging.info("Data feed started")

    def stop(self) -> None:
        logging.info("Stopping data feed")
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=self._tick_seconds * 2)
        logging.info("Data feed stopped")

    def apply_impulse(self, symbol: str, strength: float, half_life_seconds: float = 5.0) -> None:
        """Apply a decaying impulse to a symbol's return (log-return) each tick.

        strength: signed additive term to log-return per tick (e.g., 0.003 ~ +0.3% initial).
        half_life_seconds: time to halve the impulse magnitude.
        """
        with self._lock:
            if symbol not in self._impulses:
                return
            if half_life_seconds <= 0:
                decay_per_tick = 0.5
            else:
                # decay factor per tick: 0.5 every half_life_seconds
                decay_per_tick = 0.5 ** (self._tick_seconds / half_life_seconds)
            self._impulses[symbol].append((strength, decay_per_tick))

    def set_etfs(self, weights_by_etf: Dict[str, Dict[str, float]], initial_prices: Optional[Dict[str, float]] = None) -> None:
        """Define synthetic ETFs as weighted baskets of existing symbols.

        weights_by_etf: {ETF: {SYM: weight, ...}}
        initial_prices: optional starting prices for ETF to determine scale from NAV.
        """
        with self._lock:
            for etf_sym, weights in weights_by_etf.items():
                # Ensure ETF symbol is tracked
                if etf_sym not in self._prices:
                    self._prices[etf_sym] = float((initial_prices or {}).get(etf_sym, 100.0))
                # Compute current NAV
                nav = 0.0
                for usym, w in weights.items():
                    p = self._prices.get(usym)
                    if p is not None:
                        nav += w * p
                if nav <= 0:
                    scale = 1.0
                else:
                    target = float((initial_prices or {}).get(etf_sym, self._prices[etf_sym]))
                    scale = target / nav
                self._etfs[etf_sym] = (dict(weights), float(scale))
                # Initialize impulses map for the ETF symbol
                if etf_sym not in self._impulses:
                    self._impulses[etf_sym] = []


