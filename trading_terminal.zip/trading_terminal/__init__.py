"""
Local paper-trading terminal package.

Modules:
- data_feed: Simulated price feed for symbols.
- models: Order and domain models.
- engine: Order matching/execution engine.
- portfolio: Cash, positions, and PnL tracking.
- persistence: JSON save/load utilities.
- cli: Interactive terminal UI.
"""

__all__ = [
    "data_feed",
    "models",
    "engine",
    "portfolio",
    "persistence",
    "cli",
]


