from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Optional, List
import time
import uuid

# Margin coefficient: 1.0 = 100% (no leverage), 0.5 = 2x leverage
MARGIN_COEFFICIENT = 0.5


class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class OrderType(str, Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"


class StopCondition(str, Enum):
    NONE = "NONE"
    STOP_LOSS = "STOP_LOSS"
    STOP_GAIN = "STOP_GAIN"


def generate_order_id() -> str:
    return uuid.uuid4().hex


@dataclass
class Quote:
    symbol: str
    price: float  # Mid price
    timestamp: float
    bid: float = 0.0  # Bid price
    ask: float = 0.0  # Ask price
    volume: float = 0.0  # Trading volume


@dataclass
class Order:
    symbol: str
    side: Side
    quantity: int
    order_type: OrderType
    limit_price: Optional[float] = None
    stop_price: Optional[float] = None
    stop_condition: Optional[StopCondition] = None
    id: str = field(default_factory=generate_order_id)
    timestamp: float = field(default_factory=lambda: time.time())

    def validate(self) -> None:
        if self.quantity <= 0:
            raise ValueError("quantity must be > 0")
        if self.order_type == OrderType.LIMIT and (self.limit_price is None or self.limit_price <= 0):
            raise ValueError("limit_price must be > 0 for LIMIT orders")
        if self.order_type == OrderType.MARKET and self.limit_price is not None:
            raise ValueError("limit_price should be None for MARKET orders")
        if self.stop_condition and self.stop_condition != StopCondition.NONE and (self.stop_price is None or self.stop_price <= 0):
            raise ValueError("stop_price must be > 0 when stop condition is set")


@dataclass
class Fill:
    order_id: str
    symbol: str
    side: Side
    quantity: int
    price: float
    timestamp: float


@dataclass
class Position:
    symbol: str
    quantity: int = 0
    average_price: float = 0.0

    def apply_fill(self, fill: Fill) -> float:

        """Apply a fill and return realized PnL from this fill using average cost.

        Supports both long and short positions. Quantity is signed: long > 0, short < 0.
        Realized PnL is recognized only when reducing an existing position; opening or
        adding to a position does not realize PnL.
        """
        realized_pnl = 0.0

        # Convert fill to signed delta
        delta_qty = fill.quantity if fill.side == Side.BUY else -fill.quantity

        # If no existing position
        if self.quantity == 0:
            self.quantity = delta_qty
            self.average_price = fill.price
            return 0.0

        same_direction = (self.quantity > 0 and delta_qty > 0) or (self.quantity < 0 and delta_qty < 0)

        if same_direction:
            # Add to existing position; update average price
            new_abs = abs(self.quantity) + abs(delta_qty)
            self.average_price = (
                (self.average_price * abs(self.quantity)) + (fill.price * abs(delta_qty))
            ) / new_abs
            self.quantity += delta_qty
            return 0.0

        # Opposite direction: first reduce/close existing position
        close_qty = min(abs(self.quantity), abs(delta_qty))
        # For longs (quantity>0), selling realizes (price - avg) * close_qty
        # For shorts (quantity<0), buying realizes (avg - price) * close_qty
        realized_pnl = (fill.price - self.average_price) * close_qty * (1 if self.quantity > 0 else -1)

        # Update remaining position quantity after closing part
        if abs(delta_qty) > abs(self.quantity):
            # We cross through zero and open a new position in the opposite direction
            remaining = abs(delta_qty) - abs(self.quantity)
            self.quantity = remaining * (1 if delta_qty > 0 else -1)
            self.average_price = fill.price
        else:
            # We just reduced existing position without crossing zero
            self.quantity = self.quantity + delta_qty
            if self.quantity == 0:
                self.average_price = 0.0

        return realized_pnl


@dataclass
class PortfolioState:
    cash: float
    positions: Dict[str, Position] = field(default_factory=dict)
    realized_pnl: float = 0.0

    def get_unrealized_pnl(self, quotes: Dict[str, Quote]) -> float:
        unrealized = 0.0
        for symbol, pos in self.positions.items():
            quote = quotes.get(symbol)
            if quote and pos.quantity != 0:
                side_multiplier = 1 if pos.quantity > 0 else -1
                unrealized += side_multiplier * abs(pos.quantity) * (quote.price - pos.average_price)
        return unrealized

    def total_equity(self, quotes: Dict[str, Quote]) -> float:
        return self.cash + self.realized_pnl + self.get_unrealized_pnl(quotes)

    def get_required_margin(self, quotes: Dict[str, Quote]) -> float:
        """Calculate total required margin for all open positions."""
        required = 0.0
        for symbol, pos in self.positions.items():
            if pos.quantity == 0:
                continue
            quote = quotes.get(symbol)
            if quote:
                # Margin required = position value * margin coefficient
                position_value = abs(pos.quantity) * quote.price
                required += position_value * MARGIN_COEFFICIENT
        return required

    def available_margin(self, quotes: Dict[str, Quote]) -> float:
        """Calculate available margin (cash minus required margin)."""
        required = self.get_required_margin(quotes)
        return self.cash - required

    def has_sufficient_margin(self, quotes: Dict[str, Quote], order_symbol: str, order_qty: int, order_price: float) -> bool:
        """Check if there's sufficient margin to place an order."""
        # Calculate margin needed for new order
        order_value = order_qty * order_price
        order_margin = order_value * MARGIN_COEFFICIENT
        
        # Get current required margin
        current_required = self.get_required_margin(quotes)
        
        # Total required after this order
        total_required = current_required + order_margin
        
        # Check if we have enough cash
        return self.cash >= total_required


@dataclass
class EngineState:
    open_orders: Dict[str, Order] = field(default_factory=dict)
    fills: List[Fill] = field(default_factory=list)


