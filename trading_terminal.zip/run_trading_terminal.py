from trading_terminal.cli import main_loop


if __name__ == "__main__":
    # Default demo symbols
    main_loop(["AAPL", "MSFT", "GOOG", "TSLA"])


