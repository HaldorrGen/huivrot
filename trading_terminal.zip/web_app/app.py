from __future__ import annotations

import os
import threading
from typing import Dict

from flask import Flask, jsonify, request, send_from_directory

from trading_terminal.data_feed import SimulatedDataFeed
from trading_terminal.engine import TradingEngine
from trading_terminal.models import Order, OrderType, Side
from trading_terminal.portfolio import Portfolio
from trading_terminal.persistence import (
    portfolio_state_to_dict,
    portfolio_state_from_dict,
    engine_state_to_dict,
    engine_state_from_dict,
    save_json,
    load_json,
)
from .news_catalog import NEWS_ITEMS, IMPACT_LABELS_RU


def create_app(symbols: list[str] | None = None) -> Flask:
    if symbols is None:
        symbols = [
            "AAPL", "MSFT", "GOOG", "TSLA", "NVDA", "AMZN", "META", "NFLX", "AMD", "INTC",
            "BABA", "ORCL", "IBM", "UBER", "SNAP", "SHOP", "PYPL"
        ]

    app = Flask(__name__, static_folder="static", template_folder="static")

    data_dir = os.environ.get("TRADING_DATA_DIR", os.path.join(os.path.dirname(__file__), "..", "trading_state"))
    os.makedirs(data_dir, exist_ok=True)
    portfolio_path = os.path.join(data_dir, "portfolio.json")
    engine_path = os.path.join(data_dir, "engine.json")

    portfolio = Portfolio(starting_cash=100000.0)
    engine = TradingEngine(portfolio)

    # Restore state if available
    try:
        if os.path.exists(portfolio_path):
            p_state = portfolio_state_from_dict(load_json(portfolio_path))
            portfolio.load_state(p_state)
        if os.path.exists(engine_path):
            e_state = engine_state_from_dict(load_json(engine_path))
            engine.load_state(e_state)
    except Exception as e:
        print(f"Failed to load state: {e}")
    # Realistic initial prices and volatilities
    default_prices = {
        "AAPL": 190.0, "MSFT": 420.0, "GOOG": 150.0, "TSLA": 250.0, "NVDA": 900.0,
        "AMZN": 180.0, "META": 500.0, "NFLX": 620.0, "AMD": 160.0, "INTC": 35.0,
        "BABA": 85.0, "ORCL": 130.0, "IBM": 190.0, "UBER": 70.0, "SNAP": 12.0,
        "SHOP": 70.0, "PYPL": 70.0,
    }
    mu = {s: 0.0 for s in symbols}
    sigma = {s: 0.002 for s in symbols}  # ~0.2 daily mapped to per-second
    # A bit higher volatility for TSLA/NVDA/SNAP/AMD
    for s in ["TSLA", "NVDA", "SNAP", "AMD"]:
        if s in sigma: sigma[s] = 0.003
    # Prepare symbols set early (used below)
    symbols_set = set(symbols)
    feed = SimulatedDataFeed(symbols=symbols, initial_price=100.0, tick_seconds=1.0, initial_prices=default_prices, mu=mu, sigma=sigma)
    # Define a few synthetic ETFs
    etf_weights = {
        "TECH": {"AAPL": 0.15, "MSFT": 0.2, "GOOG": 0.15, "NVDA": 0.2, "AMZN": 0.15, "META": 0.15},
        "SEMIS": {"NVDA": 0.4, "AMD": 0.3, "INTC": 0.3},
        "STREAM": {"NFLX": 0.6, "AMZN": 0.2, "META": 0.2},
    }
    etf_initial = {"TECH": 300.0, "SEMIS": 200.0, "STREAM": 250.0}
    feed.set_etfs(etf_weights, initial_prices=etf_initial)
    # Include ETFs into symbols set for UI/trading
    symbols_set.update(etf_weights.keys())
    feed.subscribe(engine.on_quote)
    feed.start()

    # Risk and validation config
    max_abs_position = float(os.environ.get("TRADING_MAX_ABS_POSITION", "1000"))
    max_order_quantity = float(os.environ.get("TRADING_MAX_ORDER_QTY", "10000"))

    # Simulated news
    news_lock = threading.RLock()
    news_events: list[dict] = []

    def _news_bg():
        import random, time as _t
        while True:
            item = random.choice(NEWS_ITEMS)
            # Pick targets based on scope
            targets = list(symbols_set) if item["scope"] == "MARKET" else [random.choice(list(symbols_set))]
            
            # Add news event only ONCE per item, not per symbol
            impact_key = item["impact"]
            impact_label = IMPACT_LABELS_RU.get(impact_key, impact_key)
            evt = {
                "ts": __import__("time").time(), 
                "symbol": ",".join(targets) if len(targets) > 1 else targets[0],
                "impact": impact_key, 
                "headline": item["headline"], 
                "impactLabel": impact_label,
                "scope": item["scope"]
            }
            with news_lock:
                news_events.append(evt)
                if len(news_events) > 400:
                    news_events[:] = news_events[-400:]
            
            # Apply impulse to all targets
            try:
                base = float(item["strength"]) * 0.003 if impact_key in ("POSITIVE", "NEGATIVE") else float(item["strength"]) * 0.001 * random.uniform(-1.0, 1.0)
                strength = base if impact_key == "POSITIVE" else (-base if impact_key == "NEGATIVE" else base)
                half_life = float(item.get("half_life", 6.0))
                for sym in targets:
                    feed.apply_impulse(sym, strength=strength, half_life_seconds=half_life)
            except Exception:
                pass
            _t.sleep(random.uniform(1, 10))

    threading.Thread(target=_news_bg, daemon=True).start()

    @app.route("/api/quotes")
    def quotes():
        q = engine.get_quotes() or feed.get_last_quotes()
        return jsonify({s: {"price": v.price, "ts": v.timestamp} for s, v in q.items()})

    @app.route("/api/portfolio")
    def portfolio_state():
        quotes_map = engine.get_quotes() or feed.get_last_quotes()
        pstate = portfolio.get_state()
        return jsonify({
            "cash": pstate.cash,
            "realizedPnL": pstate.realized_pnl,
            "equity": pstate.total_equity(quotes_map),
            "positions": {sym: {"qty": pos.quantity, "avg": pos.average_price} for sym, pos in pstate.positions.items()},
        })

    @app.route("/api/health")
    def health():
        st = engine.get_state()
        quotes_map = engine.get_quotes() or {}
        return jsonify({
            "status": "ok",
            "symbols": list(symbols_set),
            "openOrders": len(st.open_orders),
            "fills": len(st.fills),
            "quotes": len(quotes_map),
        })

    @app.route("/api/orders", methods=["GET"]) 
    def list_orders():
        st = engine.get_state()
        return jsonify({
            "open": {oid: {
                "symbol": o.symbol,
                "side": o.side.value,
                "qty": o.quantity,
                "type": o.order_type.value,
                "limit": o.limit_price,
                "ts": o.timestamp,
            } for oid, o in st.open_orders.items()}
        })

    @app.route("/api/fills", methods=["GET"]) 
    def list_fills():
        st = engine.get_state()
        return jsonify([
            {
                "orderId": f.order_id,
                "symbol": f.symbol,
                "side": f.side.value,
                "qty": f.quantity,
                "price": f.price,
                "ts": f.timestamp,
            } for f in st.fills
        ])

    @app.route("/api/news", methods=["GET"]) 
    def list_news():
        limit = int(request.args.get("limit", 50))
        symbol = request.args.get("symbol")
        impact = request.args.get("impact")  # POSITIVE, NEGATIVE, NEUTRAL
        since = request.args.get("since")  # timestamp
        
        with news_lock:
            items = list(news_events)
        
        if symbol:
            symbol = symbol.upper()
            items = [n for n in items if n["symbol"] == symbol]
        
        if impact:
            impact = impact.upper()
            items = [n for n in items if n["impact"] == impact]
            
        if since:
            try:
                since_ts = float(since)
                items = [n for n in items if n["ts"] > since_ts]
            except (ValueError, TypeError):
                pass
                
        items = items[-limit:]
        return jsonify(items[::-1])

    @app.route("/api/orders", methods=["POST"]) 
    def place_order():
        data = request.get_json(force=True)
        symbol = str(data.get("symbol", "")).upper()
        side = Side(str(data.get("side")).upper())
        quantity = int(data.get("quantity"))
        order_type = OrderType(str(data.get("orderType")).upper())
        limit_price = float(data.get("limitPrice")) if data.get("limitPrice") is not None else None
        # Basic validations and risk checks
        if symbol not in symbols_set:
            return jsonify({"error": f"Unknown symbol {symbol}"}), 400
        if quantity <= 0 or quantity > max_order_quantity:
            return jsonify({"error": f"quantity must be in 1..{int(max_order_quantity)}"}), 400
        # Projected position check against max_abs_position
        pst = portfolio.get_state()
        current_qty = pst.positions.get(symbol).quantity if symbol in pst.positions else 0
        delta = quantity if side == Side.BUY else -quantity
        projected = current_qty + delta
        if abs(projected) > max_abs_position:
            return jsonify({"error": f"max abs position {int(max_abs_position)} exceeded (projected {projected})"}), 400
        order = Order(symbol=symbol, side=side, quantity=quantity, order_type=order_type, limit_price=limit_price)
        try:
            fill = engine.place_order(order)
        except Exception as e:
            return jsonify({"error": str(e)}), 400
        if fill:
            return jsonify({"status": "filled", "price": fill.price, "quantity": fill.quantity})
        return jsonify({"status": "accepted", "orderId": order.id})

    @app.route("/api/orders/<oid>", methods=["DELETE"]) 
    def cancel_order(oid: str):
        # Allow prefix
        st = engine.get_state()
        real = None
        for ko in list(st.open_orders.keys()):
            if ko.startswith(oid):
                real = ko
                break
        if not real:
            return jsonify({"error": "not found"}), 404
        ok = engine.cancel_order(real)
        return jsonify({"status": "cancelled" if ok else "not_found"})

    @app.route("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    @app.route("/static/<path:path>")
    def static_proxy(path: str):
        return send_from_directory(app.static_folder, path)

    # Background saver thread
    def _bg_save():
        while True:
            try:
                p_state = portfolio.get_state()
                e_state = engine.get_state()
                save_json(portfolio_path, portfolio_state_to_dict(p_state))
                save_json(engine_path, engine_state_to_dict(e_state))
            except Exception as e:
                print(f"Failed to save state: {e}")
            finally:
                import time as _t
                _t.sleep(5)

    t = threading.Thread(target=_bg_save, daemon=True)
    t.start()

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(host="127.0.0.1", port=5000, debug=True)



