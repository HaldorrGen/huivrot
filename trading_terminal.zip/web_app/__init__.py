"""Web app package for the trading game UI."""


