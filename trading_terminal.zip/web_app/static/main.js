const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

// Global quotes cache
let cachedQuotes = {};

async function fetchJSON(url, opts={}) {
  const res = await fetch(url, opts);
  const text = await res.text();
  if (!res.ok) {
    let msg = text;
    try { const j = JSON.parse(text); if (j && j.error) msg = j.error; } catch(_) {}
    const err = new Error(msg || `HTTP ${res.status}`);
    err.status = res.status;
    throw err;
  }
  return text ? JSON.parse(text) : null;
}

function renderQuotes(quotes) {
  const wrap = $('#quotes');
  const divs = Object.entries(quotes).map(([sym, q]) => {
    return `<div class="quote-card quote" data-symbol="${sym}">
      <div class="symbol">${sym}</div>
      <div class="price">$${q.price.toFixed(2)}</div>
    </div>`;
  }).join('');
  wrap.innerHTML = divs;

  // Make quotes clickable to select for trading
  $$('.quote-card').forEach(card => {
    card.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const symbol = card.dataset.symbol;
      if (symbol) {
        $('#symbol').value = symbol;
        $('#chartSymbol').value = symbol;
        previewOrder();
      }
    });
  });
}

async function refresh() {
  const filterSym = $('#newsSymbol')?.value || '';
  const [quotes, portfolio, orders, fills, news] = await Promise.all([
    fetchJSON('/api/quotes'),
    fetchJSON('/api/portfolio'),
    fetchJSON('/api/orders'),
    fetchJSON('/api/fills'),
    fetchNews()
  ]);

  cachedQuotes = quotes;
  populateSymbolSelects(quotes);
  renderQuotes(quotes);

  // Highlight price changes
  const oldQuotes = cachedQuotes || {};
  Object.entries(quotes).forEach(([sym, q]) => {
    const oldQ = oldQuotes[sym];
    if (oldQ && oldQ.price !== q.price) {
      highlightQuoteChange(sym, oldQ.price, q.price);
    }
  });

  $('#cash').textContent = `Cash: $ ${portfolio.cash.toFixed(2)}`;
  $('#equity').textContent = `Equity: $ ${portfolio.equity.toFixed(2)}`;
  $('#pnl').textContent = `Realized: $ ${portfolio.realizedPnL.toFixed(2)}`;

  renderPositions(portfolio, quotes);
  renderOrders(orders);
  renderFills(fills);
  updateGlobalChart(quotes);
  updateSymbolChart(quotes);
  updatePositionsChart(portfolio, quotes);
  renderNews(news);
  highlightQuotesOnNews(quotes, news);

  // Update order preview if form has values
  if ($('#symbol').value) {
    previewOrder();
  }
}

// Wire up stop loss and take profit controls
$('#useStopLoss').addEventListener('change', (e) => {
  $('#stopLoss').disabled = !e.target.checked;
  if (e.target.checked) {
    $('#stopLoss').focus();
  }
});

$('#useTakeProfit').addEventListener('change', (e) => {
  $('#takeProfit').disabled = !e.target.checked;
  if (e.target.checked) {
    $('#takeProfit').focus();
  }
});

async function placeOrder() {
  const symbol = $('#symbol').value;
  const side = $('#side').value;
  const quantity = parseInt($('#qty').value, 10);
  const orderType = $('#otype').value;
  const limitPrice = $('#lprice').value ? parseFloat($('#lprice').value) : null;
  const useStopLoss = $('#useStopLoss').checked;
  const stopLossValue = $('#stopLoss').value.trim();
  const stopLoss = useStopLoss && stopLossValue ? parseFloat(stopLossValue) : null;
  const useTakeProfit = $('#useTakeProfit').checked;
  const takeProfitValue = $('#takeProfit').value.trim();
  const takeProfit = useTakeProfit && takeProfitValue ? parseFloat(takeProfitValue) : null;

  if (!symbol) return $('#message').textContent = 'Select symbol';
  if (!['BUY','SELL'].includes(side)) return $('#message').textContent = 'Invalid side';
  if (!Number.isFinite(quantity) || quantity <= 0) return $('#message').textContent = 'Quantity must be > 0';
  if (orderType === 'LIMIT' && (!Number.isFinite(limitPrice) || limitPrice <= 0)) return $('#message').textContent = 'Limit price required';
  if (useStopLoss && !stopLoss) return $('#message').textContent = 'Stop loss price required';
  if (useTakeProfit && !takeProfit) return $('#message').textContent = 'Take profit price required';
  if (useStopLoss && stopLoss <= 0) return $('#message').textContent = 'Stop loss must be > 0';
  if (useTakeProfit && takeProfit <= 0) return $('#message').textContent = 'Take profit must be > 0';

  // Validate stop prices against current quote
  const quote = cachedQuotes[symbol];
  if (!quote) return $('#message').textContent = 'No quote available';

  if (side === 'BUY') {
    if (useStopLoss && stopLoss >= quote.price) return $('#message').textContent = 'Stop loss must be below market for longs';
    if (useTakeProfit && takeProfit <= quote.price) return $('#message').textContent = 'Take profit must be above market for longs';
  } else {
    if (useStopLoss && stopLoss <= quote.price) return $('#message').textContent = 'Stop loss must be above market for shorts';
    if (useTakeProfit && takeProfit >= quote.price) return $('#message').textContent = 'Take profit must be below market for shorts';
  }

  try {
    // Place main order
    const mainBody = { 
      symbol, 
      side, 
      quantity, 
      orderType,
      limitPrice: limitPrice
    };
    
    const mainOrder = await fetchJSON('/api/orders', { 
      method: 'POST', 
      headers: { 'Content-Type': 'application/json' }, 
      body: JSON.stringify(mainBody) 
    });

    if (mainOrder.status === 'filled') {
      $('#message').textContent = `Filled at ${mainOrder.price.toFixed(2)}`;

      // For market orders that fill immediately, place stop orders
      if (useStopLoss && stopLoss) {
        const stopLossBody = {
          symbol,
          side: side === 'BUY' ? 'SELL' : 'BUY',
          quantity,
          orderType: 'STOP',
          stopPrice: stopLoss,
          stopCondition: 'STOP_LOSS'
        };
        await fetchJSON('/api/orders', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(stopLossBody)
        });
      }

      if (useTakeProfit && takeProfit) {
        const takeProfitBody = {
          symbol,
          side: side === 'BUY' ? 'SELL' : 'BUY',
          quantity,
          orderType: 'STOP',
          stopPrice: takeProfit,
          stopCondition: 'TAKE_PROFIT'
        };
        await fetchJSON('/api/orders', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(takeProfitBody)
        });
      }
    } else {
      $('#message').textContent = 'Order accepted';
    }

    await refresh();
  } catch (e) {
    $('#message').textContent = `Error: ${e.message}`;
  }
}

function renderOrders(orders) {
  const wrap = $('#orders');
  const entries = Object.entries(orders.open);
  if (entries.length === 0) { wrap.innerHTML = '<em>No open orders</em>'; return; }
  const table = document.createElement('table');
  table.innerHTML = `<thead><tr><th>Id</th><th>Symbol</th><th>Side</th><th>Qty</th><th>Type</th><th>Limit</th><th>Action</th></tr></thead><tbody></tbody>`;
  const tb = table.querySelector('tbody');
  entries.forEach(([oid, o]) => {
    const tr = document.createElement('tr');
    const shortId = oid.slice(0, 8);
    tr.innerHTML = `<td>${shortId}</td><td>${o.symbol}</td><td>${o.side}</td><td>${o.qty}</td><td>${o.type}</td><td>${o.limit ?? ''}</td><td><button data-oid="${shortId}" class="cancel">Cancel</button></td>`;
    tb.appendChild(tr);
  });
  wrap.innerHTML = '';
  wrap.appendChild(table);
  $$('#orders .cancel').forEach(btn => btn.addEventListener('click', async (e) => {
    const prefix = e.target.getAttribute('data-oid');
    try {
      await fetchJSON(`/api/orders/${prefix}`, { method: 'DELETE' });
      await refresh();
    } catch (err) {
      $('#message').textContent = `Cancel error: ${err.message}`;
    }
  }));
}

function renderFills(fills) {
  const wrap = $('#fills');
  if (!fills.length) { wrap.innerHTML = '<em>No fills yet</em>'; return; }
  const table = document.createElement('table');
  table.innerHTML = `<thead><tr><th>Time</th><th>Order</th><th>Symbol</th><th>Side</th><th>Qty</th><th>Price</th></tr></thead><tbody></tbody>`;
  const tb = table.querySelector('tbody');
  fills.slice(-100).reverse().forEach(f => {
    const tr = document.createElement('tr');
    const dt = new Date(f.ts * 1000).toLocaleTimeString();
    tr.innerHTML = `<td>${dt}</td><td>${f.orderId.slice(0,8)}</td><td>${f.symbol}</td><td>${f.side}</td><td>${f.qty}</td><td>${f.price.toFixed(2)}</td>`;
    tb.appendChild(tr);
  });
  wrap.innerHTML = '';
  wrap.appendChild(table);
}

// Global index chart (average of all prices)
let chartGlobal, chartGlobalData = { labels: [], prices: [] };
function updateGlobalChart(quotes) {
  const syms = Object.keys(quotes);
  if (!syms.length) return;
  const avg = syms.reduce((acc, s) => acc + quotes[s].price, 0) / syms.length;
  const ts = new Date(quotes[syms[0]].ts * 1000).toLocaleTimeString();
  chartGlobalData.labels.push(ts);
  chartGlobalData.prices.push(avg);
  if (chartGlobalData.labels.length > 120) { chartGlobalData.labels.shift(); chartGlobalData.prices.shift(); }
  if (!chartGlobal) {
    const ctx = document.getElementById('chartGlobal').getContext('2d');
    chartGlobal = new Chart(ctx, {
      type: 'line',
      data: { labels: chartGlobalData.labels, datasets: [{ label: 'INDEX', data: chartGlobalData.prices, borderColor: '#1e88e5', tension: 0.2, pointRadius: 0 }] },
      options: { responsive: true, animation: false, scales: { x: { display: true }, y: { display: true } }, plugins: { legend: { display: false } } }
    });
  } else {
    chartGlobal.data.labels = chartGlobalData.labels;
    chartGlobal.data.datasets[0].data = chartGlobalData.prices;
    chartGlobal.update('none');
  }
}

// Selected symbol chart
let chartSym, chartSymData = { labels: [], prices: [], symbol: null };
function updateSymbolChart(quotes) {
  const sel = $('#chartSymbol');
  const symbol = sel?.value || Object.keys(quotes)[0];
  if (!symbol || !quotes[symbol]) return;
  const ts = new Date(quotes[symbol].ts * 1000).toLocaleTimeString();
  if (chartSymData.symbol !== symbol) {
    chartSymData = { labels: [], prices: [], symbol };
  }
  chartSymData.labels.push(ts);
  chartSymData.prices.push(quotes[symbol].price);
  if (chartSymData.labels.length > 120) { chartSymData.labels.shift(); chartSymData.prices.shift(); }
  if (!chartSym) {
    const ctx = document.getElementById('chartSymbolCanvas').getContext('2d');
    chartSym = new Chart(ctx, {
      type: 'line',
      data: { labels: chartSymData.labels, datasets: [{ label: symbol, data: chartSymData.prices, borderColor: '#ff9800', tension: 0.2, pointRadius: 0 }] },
      options: { responsive: true, animation: false, scales: { x: { display: true }, y: { display: true } }, plugins: { legend: { display: false } } }
    });
  } else {
    chartSym.data.labels = chartSymData.labels;
    chartSym.data.datasets[0].label = symbol;
    chartSym.data.datasets[0].data = chartSymData.prices;
    chartSym.update('none');
  }
}

// Position performance chart
let chartPositions;
let chartPositionsData = { labels: [], values: [] };

function updatePositionsChart(portfolio, quotes) {
  const equities = [];
  const ts = new Date().toLocaleTimeString();
  
  let totalEquity = portfolio.cash;
  for (const [sym, pos] of Object.entries(portfolio.positions)) {
    if (quotes[sym]) {
      totalEquity += pos.qty * quotes[sym].price;
    }
  }
  
  chartPositionsData.labels.push(ts);
  chartPositionsData.values.push(totalEquity);
  
  if (chartPositionsData.labels.length > 120) {
    chartPositionsData.labels.shift();
    chartPositionsData.values.shift();
  }
  
  if (!chartPositions) {
    const ctx = document.getElementById('chartPositions').getContext('2d');
    chartPositions = new Chart(ctx, {
      type: 'line',
      data: {
        labels: chartPositionsData.labels,
        datasets: [{
          label: 'Portfolio Value',
          data: chartPositionsData.values,
          borderColor: '#73daca',
          tension: 0.2,
          pointRadius: 0
        }]
      },
      options: {
        responsive: true,
        animation: false,
        scales: { 
          x: { display: true },
          y: { 
            display: true,
            ticks: {
              callback: function(value) {
                return '$ ' + value.toLocaleString();
              }
            }
          }
        },
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: function(context) {
                return '$ ' + context.parsed.y.toLocaleString();
              }
            }
          }
        }
      }
    });
  } else {
    chartPositions.data.labels = chartPositionsData.labels;
    chartPositions.data.datasets[0].data = chartPositionsData.values;
    chartPositions.update('none');
  }
}

// Add order type dependent price validation
$('#otype').addEventListener('change', (e) => {
  const isLimit = e.target.value === 'LIMIT';
  $('#lprice').disabled = !isLimit;
  $('#lprice').required = isLimit;
});

// Add order preview functionality
function previewOrder() {
  const symbol = $('#symbol').value;
  const side = $('#side').value;
  const quantity = parseInt($('#qty').value, 10);
  const orderType = $('#otype').value;
  const limitPrice = $('#lprice').value ? parseFloat($('#lprice').value) : null;
  const useStopLoss = $('#useStopLoss').checked;
  const stopLoss = useStopLoss ? parseFloat($('#stopLoss').value) : null;
  const useTakeProfit = $('#useTakeProfit').checked;
  const takeProfit = useTakeProfit ? parseFloat($('#takeProfit').value) : null;
  
  if (!symbol || !Number.isFinite(quantity) || quantity <= 0) {
    $('#preview').textContent = '';
    return;
  }
  
  const quote = cachedQuotes[symbol];
  if (!quote) {
    $('#preview').textContent = 'No quote available';
    return;
  }
  
  const price = orderType === 'LIMIT' ? limitPrice : quote.price;
  const total = price * quantity;
  
  let preview = `Estimated total: $ ${total.toFixed(2)}<br>Market price: $ ${quote.price.toFixed(2)}`;
  
  if (useStopLoss) {
    const stopLossAmount = Math.abs((price - stopLoss) * quantity);
    preview += `<br>Max loss: $ ${stopLossAmount.toFixed(2)}`;
  }
  
  if (useTakeProfit) {
    const takeProfitAmount = Math.abs((takeProfit - price) * quantity);
    preview += `<br>Target profit: $ ${takeProfitAmount.toFixed(2)}`;
  }
  
  $('#preview').innerHTML = preview;
}

// Wire up preview updates
['symbol', 'side', 'qty', 'otype', 'lprice', 'useStopLoss', 'stopLoss', 'useTakeProfit', 'takeProfit'].forEach(id => {
  $(`#${id}`).addEventListener('change', previewOrder);
  $(`#${id}`).addEventListener('keyup', previewOrder);
});

// Enhance position display
function renderPositions(portfolio, quotes) {
  const posWrap = $('#positions');
  const entries = Object.entries(portfolio.positions);
  
  if (entries.length === 0) {
    posWrap.innerHTML = '<em>No positions</em>';
    return;
  }
  
  const table = document.createElement('table');
  table.innerHTML = `
    <thead>
      <tr>
        <th>Symbol</th>
        <th>Qty</th>
        <th>Avg Price</th>
        <th>Mark</th>
        <th>Unrealized</th>
        <th>% Change</th>
        <th>Value</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody></tbody>
  `;
  
  const tb = table.querySelector('tbody');
  
  entries.forEach(([sym, p]) => {
    const mark = quotes[sym]?.price ?? p.avg;
    const unreal = (mark - p.avg) * p.qty;
    const pctChange = ((mark / p.avg - 1) * 100);
    const value = mark * p.qty;
    const isLong = p.qty > 0;
    
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${sym}</td>
      <td>${p.qty}</td>
      <td>$ ${p.avg.toFixed(2)}</td>
      <td>$ ${mark.toFixed(2)}</td>
      <td class="${unreal>=0?'pnl-pos':'pnl-neg'}">$ ${unreal.toFixed(2)}</td>
      <td class="${pctChange>=0?'pnl-pos':'pnl-neg'}">${pctChange.toFixed(2)}%</td>
      <td>$ ${value.toFixed(2)}</td>
      <td>
        <button class="close-position" data-symbol="${sym}" data-qty="${p.qty}">Close</button>
        <button class="close-half" data-symbol="${sym}" data-qty="${Math.floor(Math.abs(p.qty/2))}">${Math.floor(Math.abs(p.qty/2))}x</button>
      </td>
    `;
    tb.appendChild(tr);
  });
  
  posWrap.innerHTML = '';
  posWrap.appendChild(table);
  
  // Wire up position action buttons
  $$('.close-position').forEach(btn => {
    btn.addEventListener('click', async () => {
      const symbol = btn.dataset.symbol;
      const qty = Math.abs(parseInt(btn.dataset.qty));
      const quote = quotes[symbol];
      if (!quote) return;
      
      try {
        const order = {
          symbol,
          side: btn.dataset.qty > 0 ? 'SELL' : 'BUY',
          quantity: qty,
          orderType: 'MARKET'
        };
        
        await fetchJSON('/api/orders', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(order)
        });
        
        await refresh();
      } catch (e) {
        $('#message').textContent = `Close error: ${e.message}`;
      }
    });
  });
  
  $$('.close-half').forEach(btn => {
    btn.addEventListener('click', async () => {
      const symbol = btn.dataset.symbol;
      const qty = Math.abs(parseInt(btn.dataset.qty));
      const quote = quotes[symbol];
      if (!quote) return;
      
      try {
        const order = {
          symbol,
          side: btn.dataset.qty > 0 ? 'SELL' : 'BUY',
          quantity: qty,
          orderType: 'MARKET'
        };
        
        await fetchJSON('/api/orders', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(order)
        });
        
        await refresh();
      } catch (e) {
        $('#message').textContent = `Close error: ${e.message}`;
      }
    });
  });
}

// Add keyboard shortcuts
document.addEventListener('keydown', (e) => {
  if (e.target.tagName === 'INPUT') return; // Don't trigger when typing in inputs
  
  if (e.key === 'b' || e.key === 'B') {
    $('#side').value = 'BUY';
    $('#qty').focus();
  } else if (e.key === 's' || e.key === 'S') {
    $('#side').value = 'SELL';
    $('#qty').focus();
  } else if (e.key === 'm' || e.key === 'M') {
    $('#otype').value = 'MARKET';
  } else if (e.key === 'l' || e.key === 'L') {
    $('#otype').value = 'LIMIT';
    $('#lprice').focus();
  }
});

// Add quote highlighting on price changes
function highlightQuoteChange(symbol, oldPrice, newPrice) {
  $$('#quotes .quote').forEach(el => {
    if (el.querySelector('.sym')?.textContent === symbol) {
      el.classList.remove('up', 'down');
      if (oldPrice < newPrice) {
        el.classList.add('up');
      } else if (oldPrice > newPrice) {
        el.classList.add('down');
      }
    }
  });
}

function highlightQuotesOnNews(quotes, news) {
  // Reset all highlights first
  $$('.quote-card').forEach(card => {
    card.classList.remove('positive', 'negative', 'neutral');
  });
  
  // Apply latest news impact to quotes
  news.forEach(item => {
    const quoteCard = $(`.quote-card[data-symbol="${item.symbol}"]`);
    if (quoteCard) {
      quoteCard.classList.add(item.impact.toLowerCase());
    }
  });
}

function wire() {
  $('#submit').addEventListener('click', placeOrder);
  
  // Wire up symbol selection to update charts
  $('#symbol').addEventListener('change', () => {
    const symbol = $('#symbol').value;
    if (symbol) {
      $('#chartSymbol').value = symbol;
      previewOrder();
    }
  });
  
  $('#chartSymbol').addEventListener('change', () => {
    chartSymData.symbol = null; // Reset chart data to redraw with new symbol
    previewOrder();
  });
  
  // Initial refresh
  refresh();
  
  // Update portfolio, orders, fills every 5 seconds
  setInterval(async () => {
    try {
      const [quotes, portfolio, orders, fills] = await Promise.all([
        fetchJSON('/api/quotes'),
        fetchJSON('/api/portfolio'),
        fetchJSON('/api/orders'),
        fetchJSON('/api/fills')
      ]);

      cachedQuotes = quotes;

      $('#cash').textContent = `Cash: $ ${portfolio.cash.toFixed(2)}`;
      $('#equity').textContent = `Equity: $ ${portfolio.equity.toFixed(2)}`;
      $('#pnl').textContent = `Realized: $ ${portfolio.realizedPnL.toFixed(2)}`;

      renderPositions(portfolio, quotes);
      renderOrders(orders);
      renderFills(fills);
      updateGlobalChart(quotes);
      updateSymbolChart(quotes);
      updatePositionsChart(portfolio, quotes);
      
      // Update symbol selects if quotes changed
      populateSymbolSelects(quotes);

      if ($('#symbol').value) {
        previewOrder();
      }
    } catch (e) {
      console.error('Refresh error:', e);
    }
  }, 5000); // 5 seconds for charts
  
  // Update news every 10 seconds
  setInterval(async () => {
    try {
      const news = await fetchNews();
      const quotes = await fetchJSON('/api/quotes');
      renderNews(news);
      highlightQuotesOnNews(quotes, news);
    } catch (e) {
      console.error('News refresh error:', e);
    }
  }, 10000); // 10 seconds for news
}

let lastNewsUpdate = 0;

// Add impact filter to news
$('#newsFilter').addEventListener('change', () => {
  refresh();
});

async function fetchNews() {
  const symbol = $('#newsSymbol')?.value || '';
  const impact = $('#newsFilter')?.value || '';
  const ts = Date.now();
  const url = `/api/news?limit=50${symbol ? `&symbol=${encodeURIComponent(symbol)}` : ''}${impact ? `&impact=${encodeURIComponent(impact)}` : ''}&_=${ts}`;
  const news = await fetchJSON(url);
  if (news.length) {
    lastNewsUpdate = Math.max(lastNewsUpdate, ...news.map(n => n.ts));
  }
  return news;
}

function renderNews(items) {
  const wrap = $('#news');
  if (!items.length) { 
    wrap.innerHTML = '<em>Нет новостей</em>'; 
    const meta = $('#newsMeta'); 
    if (meta) meta.textContent = '(0)'; 
    return; 
  }

  const list = document.createElement('ul');
  items.forEach(n => {
    const li = document.createElement('li');
    const dt = new Date(n.ts * 1000).toLocaleTimeString();
    const label = n.impactLabel || n.impact;
    
    // Make symbol clickable to filter
    li.innerHTML = `
      <span class="time">${dt}</span>
      <strong>[<a href="#" class="symbol-link" data-symbol="${n.symbol}">${n.symbol}</a>]</strong>
      <span class="impact ${String(n.impact).toLowerCase()}">${label}</span>
      — ${n.headline}
    `;
    list.appendChild(li);
  });

  // Handle symbol link clicks
  list.querySelectorAll('.symbol-link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const symbol = e.target.dataset.symbol;
      $('#newsSymbol').value = symbol;
      $('#chartSymbol').value = symbol;
      refresh();
    });
  });

  wrap.innerHTML = '';
  wrap.appendChild(list);

  const meta = $('#newsMeta');
  if (meta) {
    const dt = new Date().toLocaleTimeString();
    meta.textContent = `(${items.length} • обновлено ${dt})`;
  }
}

// Update the refresh function to use new news fetching
const _refreshBase = refresh;
refresh = async function() {
  const [quotes, portfolio, orders, fills, news] = await Promise.all([
    fetchJSON('/api/quotes'),
    fetchJSON('/api/portfolio'),
    fetchJSON('/api/orders'),
    fetchJSON('/api/fills'),
    fetchNews()
  ]);

  cachedQuotes = quotes;

  $('#cash').textContent = `Cash: $ ${portfolio.cash.toFixed(2)}`;
  $('#equity').textContent = `Equity: $ ${portfolio.equity.toFixed(2)}`;
  $('#pnl').textContent = `Realized: $ ${portfolio.realizedPnL.toFixed(2)}`;

  renderPositions(portfolio, quotes);
  renderOrders(orders);
  renderFills(fills);
  updateGlobalChart(quotes);
  updateSymbolChart(quotes);
  updatePositionsChart(portfolio, quotes);
  renderNews(news);
  highlightQuotesOnNews(quotes, news);

  if ($('#symbol').value) {
    previewOrder();
  }
};

// Keyboard shortcuts modal handling
document.addEventListener('keydown', (e) => {
  if (e.target.tagName === 'INPUT') return;
  
  if (e.key === '?') {
    $('#shortcutsModal').style.display = $('#shortcutsModal').style.display === 'none' ? 'flex' : 'none';
  } else if (e.key === 'Escape') {
    $('#shortcutsModal').style.display = 'none';
  } else if (e.key === 'b' || e.key === 'B') {
    $('#side').value = 'BUY';
    $('#qty').focus();
    e.preventDefault();
  } else if (e.key === 's' || e.key === 'S') {
    $('#side').value = 'SELL';
    $('#qty').focus();
    e.preventDefault();
  } else if (e.key === 'm' || e.key === 'M') {
    $('#otype').value = 'MARKET';
    $('#qty').focus();
    e.preventDefault();
  } else if (e.key === 'l' || e.key === 'L') {
    $('#otype').value = 'LIMIT';
    $('#lprice').disabled = false;
    $('#lprice').focus();
    e.preventDefault();
  } else if (e.key === 'Enter' && e.ctrlKey) {
    $('#submit').click();
    e.preventDefault();
  }
});

// Close modal on button click
$('.close-modal')?.addEventListener('click', () => {
  $('#shortcutsModal').style.display = 'none';
});

// Close modal when clicking outside
$('#shortcutsModal')?.addEventListener('click', (e) => {
  if (e.target === $('#shortcutsModal')) {
    $('#shortcutsModal').style.display = 'none';
  }
});

// Populate symbol dropdowns
function populateSymbolSelects(quotes) {
  const symbols = Object.keys(quotes).sort();
  const selects = ['#symbol', '#chartSymbol', '#newsSymbol'];
  
  selects.forEach(selector => {
    const select = $(selector);
    if (!select) return;
    
    // Save current value
    const currentValue = select.value;
    
    // Clear and repopulate
    select.innerHTML = selector === '#newsSymbol' 
      ? '<option value="">Все</option>' 
      : '';
      
    symbols.forEach(sym => {
      const opt = document.createElement('option');
      opt.value = sym;
      opt.textContent = sym;
      select.appendChild(opt);
    });
    
    // Restore selection if it still exists
    if (currentValue && symbols.includes(currentValue)) {
      select.value = currentValue;
    }
  });
}

document.addEventListener('DOMContentLoaded', wire);



