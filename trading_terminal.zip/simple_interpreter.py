import math

class Token:
    def __init__(self, type, value):
        self.type = type
        self.value = value

class Tokenizer:
    def __init__(self):
        self.digits = '0123456789.'
        self.letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
        
    def tokenize(self, text):
        tokens = []
        i = 0
        while i < len(text):
            char = text[i]
            
            if char.isspace():
                i += 1
                continue
                
            if char in self.digits or (char == '-' and i + 1 < len(text) and text[i + 1] in self.digits):
                num = char
                i += 1
                while i < len(text) and (text[i] in self.digits):
                    num += text[i]
                    i += 1
                tokens.append(Token('NUMBER', float(num)))
                continue
                
            if char == '"' or char == "'":
                string = ''
                quote = char
                i += 1
                while i < len(text) and text[i] != quote:
                    string += text[i]
                    i += 1
                if i < len(text):  # Skip closing quote
                    i += 1
                tokens.append(Token('STRING', string))
                continue
                
            if char in self.letters:
                var = ''
                while i < len(text) and text[i] in self.letters:
                    var += text[i]
                    i += 1
                tokens.append(Token('IDENTIFIER', var))
                continue
                
            if char in '+-*/()=<>![],:':  # Added [],:
                if i + 1 < len(text) and text[i:i+2] in ['==', '!=', '<=', '>=', 'and', 'or']:
                    tokens.append(Token('OPERATOR', text[i:i+2]))
                    i += 2
                else:
                    tokens.append(Token('OPERATOR', char))
                    i += 1
                continue
                
            raise Exception(f'Invalid character: {char}')
            
        return tokens

class Interpreter:
    def __init__(self):
        self.variables = {}
        self.tokenizer = Tokenizer()
        self.commands = {
            'help': self.show_help,
            'clear': self.clear_vars,
            'vars': self.show_vars
        }
        self.functions = {
            'sin': math.sin,
            'cos': math.cos,
            'sqrt': math.sqrt,
            'abs': abs,
            'round': round,
            'len': len,
            'min': min,
            'max': max,
            'sum': sum,
            'pow': pow,
            'log': math.log,
            'log10': math.log10,
            'exp': math.exp,
            'floor': math.floor,
            'ceil': math.ceil
        }
        self.string_methods = {
            'upper': str.upper,
            'lower': str.lower,
            'strip': str.strip,
            'split': str.split
        }
        self.list_methods = {
            'append': list.append,
            'pop': list.pop,
            'reverse': list.reverse
        }
        self.functions.update({
            'range': range,
            'str': str,
            'int': int,
            'float': float,
            'bool': bool,
            'dict': dict,
            'list': list
        })
    
    def show_help(self):
        """Show available commands and basic syntax"""
        help_text = """
Available commands:
  help  - Show this help message
  clear - Clear all variables
  vars  - Show all defined variables
  exit  - Exit the interpreter

Built-in functions:
  sin(x)   - Sine of x
  cos(x)   - Cosine of x
  sqrt(x)  - Square root of x
  abs(x)   - Absolute value of x
  round(x) - Round x to nearest integer
  len(list)     # List length
  min(list)     # Minimum value
  max(list)     # Maximum value
  sum(list)     # Sum of values
  pow(x, y)     # x raised to power y
  log(x)        # Natural logarithm
  exp(x)        # e raised to power x
  floor(x)      # Largest integer <= x
  ceil(x)       # Smallest integer >= x

Basic syntax:
  x = 5          # Variable assignment
  2 + 3 * 4      # Arithmetic operations
  (1 + 2) * 3    # Parentheses for grouping
  5 == 3         # Comparison operators (==, !=, <, >, <=, >=)
  "Hello"        # String literals

List operations:
  [1, 2, 3]     # List literal
  len(list)     # List length
  min(list)     # Minimum value
  max(list)     # Maximum value
  sum(list)     # Sum of values

Boolean operations:
  x and y       # Logical AND
  x or y        # Logical OR
  not x         # Logical NOT

If statements:
  if x > 0 then y else z

Loops:
  while x > 0 do ... end
  for i in range(0, 10) do ... end

String methods:
  "text".upper()  # Convert to uppercase
  "text".lower()  # Convert to lowercase
  " text ".strip() # Remove leading/trailing spaces
  "a,b,c".split(",") # Split string by delimiter

List methods:
  list.append(x)  # Append x to list
  list.pop()      # Remove and return last element
  list.reverse()  # Reverse the list

Dictionaries:
  {"key": "value"}  # Dictionary literal
"""
        print(help_text)
        return None

    def clear_vars(self):
        """Clear all defined variables"""
        self.variables.clear()
        print("All variables cleared")
        return None

    def show_vars(self):
        """Show all defined variables"""
        if not self.variables:
            print("No variables defined")
            return None
        for name, value in self.variables.items():
            print(f"{name} = {value}")
        return None
    
    def evaluate(self, tokens):
        if not tokens:
            return None
            
        # Handle assignment
        if len(tokens) >= 3 and tokens[0].type == 'IDENTIFIER' and tokens[1].value == '=':
            var_name = tokens[0].value
            result = self.evaluate_expression(tokens[2:])
            self.variables[var_name] = result
            return result
            
        return self.evaluate_expression(tokens)
    
    def evaluate_expression(self, tokens):
        if not tokens:
            return None
            
        if len(tokens) == 1:
            if tokens[0].type == 'NUMBER':
                return tokens[0].value
            if tokens[0].type == 'IDENTIFIER':
                if tokens[0].value in self.variables:
                    return self.variables[tokens[0].value]
                raise Exception(f'Undefined variable: {tokens[0].value}')
            if tokens[0].type == 'STRING':
                return tokens[0].value
        
        # Convert to postfix notation using shunting yard algorithm
        output_queue = []
        operator_stack = []
        ops = {
            '+': (1, 'left'),
            '-': (1, 'left'),
            '*': (2, 'left'),
            '/': (2, 'left'),
            '==': (0, 'left'),
            '!=': (0, 'left'),
            '<': (0, 'left'),
            '>': (0, 'left'),
            '<=': (0, 'left'),
            '>=': (0, 'left'),
            'and': (0, 'left'),
            'or': (0, 'left'),
            'not': (0, 'right')
        }
        
        # Handle function calls
        if (len(tokens) >= 4 and 
            tokens[0].type == 'IDENTIFIER' and 
            tokens[0].value in self.functions and 
            tokens[1].value == '('):
            
            func_name = tokens[0].value
            arg_tokens = []
            paren_count = 0
            i = 2
            while i < len(tokens):
                if tokens[i].value == '(':
                    paren_count += 1
                elif tokens[i].value == ')':
                    if paren_count == 0:
                        break
                    paren_count -= 1
                arg_tokens.append(tokens[i])
                i += 1
                
            if i < len(tokens):
                arg_value = self.evaluate_expression(arg_tokens)
                return self.functions[func_name](arg_value)
        
        # Handle list literals
        if tokens[0].value == '[':
            elements = []
            current_element = []
            i = 1
            while i < len(tokens):
                if tokens[i].value == ']':
                    if current_element:
                        elements.append(self.evaluate_expression(current_element))
                    return elements
                elif tokens[i].value == ',':
                    if current_element:
                        elements.append(self.evaluate_expression(current_element))
                        current_element = []
                else:
                    current_element.append(tokens[i])
                i += 1
            raise Exception('Unclosed list literal')
        
        # Handle dictionary literals
        if tokens[0].value == '{':
            dict_result = {}
            key_tokens = []
            value_tokens = []
            expect_value = False
            i = 1
            while i < len(tokens):
                if tokens[i].value == '}':
                    if key_tokens and value_tokens:
                        key = self.evaluate_expression(key_tokens)
                        value = self.evaluate_expression(value_tokens)
                        dict_result[key] = value
                    return dict_result
                elif tokens[i].value == ':':
                    expect_value = True
                elif tokens[i].value == ',':
                    key = self.evaluate_expression(key_tokens)
                    value = self.evaluate_expression(value_tokens)
                    dict_result[key] = value
                    key_tokens = []
                    value_tokens = []
                    expect_value = False
                else:
                    if expect_value:
                        value_tokens.append(tokens[i])
                    else:
                        key_tokens.append(tokens[i])
                i += 1

        # Handle if-then statements
        if len(tokens) >= 4 and tokens[0].value == 'if':
            condition_tokens = []
            then_tokens = []
            else_tokens = []
            i = 1
            while i < len(tokens) and tokens[i].value != 'then':
                condition_tokens.append(tokens[i])
                i += 1
            i += 1  # Skip 'then'
            while i < len(tokens) and tokens[i].value != 'else':
                then_tokens.append(tokens[i])
                i += 1
            i += 1  # Skip 'else'
            while i < len(tokens):
                else_tokens.append(tokens[i])
                i += 1
                
            condition = self.evaluate_expression(condition_tokens)
            if condition:
                return self.evaluate_expression(then_tokens)
            elif else_tokens:
                return self.evaluate_expression(else_tokens)
            return None

        # Handle while loops
        if len(tokens) >= 3 and tokens[0].value == 'while':
            condition_tokens = []
            body_tokens = []
            i = 1
            while i < len(tokens) and tokens[i].value != 'do':
                condition_tokens.append(tokens[i])
                i += 1
            i += 1  # Skip 'do'
            while i < len(tokens) and tokens[i].value != 'end':
                body_tokens.append(tokens[i])
                i += 1
                
            result = None
            while self.evaluate_expression(condition_tokens):
                result = self.evaluate_expression(body_tokens)
            return result

        # Handle for loops
        if len(tokens) >= 3 and tokens[0].value == 'for':
            var_name = tokens[1].value
            in_pos = 2
            while tokens[in_pos].value != 'in':
                in_pos += 1
            
            iter_tokens = tokens[in_pos + 1:]
            iterable = self.evaluate_expression(iter_tokens)
            
            result = None
            for val in iterable:
                self.variables[var_name] = val
                result = self.evaluate_expression(body_tokens)
            return result

        # Handle method calls (for strings and lists)
        if (len(tokens) >= 4 and 
            tokens[1].value == '.' and 
            tokens[2].type == 'IDENTIFIER'):
            
            obj = self.evaluate_expression([tokens[0]])
            method_name = tokens[2].value
            args_start = 4  # after the opening parenthesis
            
            if isinstance(obj, str) and method_name in self.string_methods:
                method = self.string_methods[method_name]
                args = self.evaluate_expression(tokens[args_start:-1])
                return method(obj, args) if args else method(obj)
                
            elif isinstance(obj, list) and method_name in self.list_methods:
                method = self.list_methods[method_name]
                args = self.evaluate_expression(tokens[args_start:-1])
                return method(obj, args) if args else method(obj)
        
        i = 0
        while i < len(tokens):
            token = tokens[i]
            
            if token.type == 'NUMBER' or token.type == 'IDENTIFIER' or token.type == 'STRING':
                output_queue.append(token)
            elif token.value == '(':
                operator_stack.append(token)
            elif token.value == ')':
                while operator_stack and operator_stack[-1].value != '(':
                    output_queue.append(operator_stack.pop())
                if operator_stack:  # Remove the '('
                    operator_stack.pop()
            elif token.value in ops:
                while (operator_stack and 
                       operator_stack[-1].value != '(' and
                       ops.get(operator_stack[-1].value, (0, ''))[0] >= ops[token.value][0]):
                    output_queue.append(operator_stack.pop())
                operator_stack.append(token)
            i += 1
        
        while operator_stack:
            output_queue.append(operator_stack.pop())
        
        # Evaluate postfix expression
        eval_stack = []
        for token in output_queue:
            if token.type in ('NUMBER', 'IDENTIFIER', 'STRING'):
                if token.type == 'NUMBER':
                    eval_stack.append(token.value)
                elif token.type == 'STRING':
                    eval_stack.append(token.value)
                else:
                    if token.value in self.variables:
                        eval_stack.append(self.variables[token.value])
                    else:
                        raise Exception(f'Undefined variable: {token.value}')
            else:
                if len(eval_stack) < 2:
                    raise Exception('Invalid expression')
                    
                b = eval_stack.pop()
                a = eval_stack.pop()
                
                if token.value == '+': 
                    if isinstance(a, list):
                        eval_stack.append(a + b)
                    else:
                        eval_stack.append(a + b)
                elif token.value == '-': eval_stack.append(a - b)
                elif token.value == '*': eval_stack.append(a * b)
                elif token.value == '/': 
                    if b == 0:
                        raise Exception('Division by zero')
                    eval_stack.append(a / b)
                elif token.value == '==': eval_stack.append(1.0 if a == b else 0.0)
                elif token.value == '!=': eval_stack.append(1.0 if a != b else 0.0)
                elif token.value == '<': eval_stack.append(1.0 if a < b else 0.0)
                elif token.value == '>': eval_stack.append(1.0 if a > b else 0.0)
                elif token.value == '<=': eval_stack.append(1.0 if a <= b else 0.0)
                elif token.value == '>=': eval_stack.append(1.0 if a >= b else 0.0)
                elif token.value == 'and': eval_stack.append(1.0 if a and b else 0.0)
                elif token.value == 'or': eval_stack.append(1.0 if a or b else 0.0)
                elif token.value == 'not': eval_stack.append(1.0 if not a else 0.0)
        
        if len(eval_stack) != 1:
            raise Exception('Invalid expression')
            
        return eval_stack[0]

def main():
    try:
        import readline  # Enable command history
    except ImportError:
        pass  # readline not available on Windows
        
    interpreter = Interpreter()
    print("Simple Python Interpreter (type 'help' for commands, 'exit' to quit)")
    
    while True:
        try:
            text = input('>>> ').strip()
            if not text:
                continue
                
            if text.lower() == 'exit':
                break
                
            # Check for built-in commands
            command = text.lower()
            if command in interpreter.commands:
                interpreter.commands[command]()
                continue
                
            tokens = interpreter.tokenizer.tokenize(text)
            result = interpreter.evaluate(tokens)
            if result is not None:
                print(f"=> {result}")
                
        except KeyboardInterrupt:
            print("\nUse 'exit' to quit")
        except Exception as e:
            print(f"Error: {e}")

if __name__ == '__main__':
    main()
